import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:trufi_core/blocs/app_review_cubit.dart';
import 'package:trufi_core/blocs/home_page_cubit.dart';
import 'package:trufi_core/blocs/payload_data_plan/payload_data_plan_cubit.dart';
import 'package:trufi_core/blocs/preferences/preferences_cubit.dart';
import 'package:trufi_core/entities/ad_entity/ad_entity.dart';
import 'package:trufi_core/entities/plan_entity/plan_entity.dart';
import 'package:trufi_core/keys.dart' as keys;
import 'package:trufi_core/l10n/trufi_localization.dart';
import 'package:trufi_core/pages/home/plan_map/plan.dart';
import 'package:trufi_core/trufi_app.dart';
import 'package:trufi_core/widgets/fetch_error_handler.dart';

import 'details_screen.dart';
import 'widgets/card_itinerary.dart';

class ResultsScreen extends StatefulWidget {
  static const String route = '/';
  final LocaleWidgetBuilder customOverlayWidget;
  final WidgetBuilder customBetweenFabWidget;
  final PlanEntity plan;
  final AdEntity ad;

  const ResultsScreen({
    Key key,
    this.customOverlayWidget,
    this.customBetweenFabWidget,
    @required this.plan,
    this.ad,
  }) : super(key: key);

  @override
  _ResultsScreenState createState() => _ResultsScreenState();
}

class _ResultsScreenState extends State<ResultsScreen> {
  PlanPageController _planPageController;

  @override
  void initState() {
    super.initState();
    _planPageController = PlanPageController(widget.plan, widget.ad);
    if (_planPageController.plan.itineraries.isNotEmpty) {
      _planPageController.inSelectedItinerary.add(
        _planPageController.plan.itineraries.first,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isPortrait =
        MediaQuery.of(context).orientation == Orientation.portrait;
    final localization = TrufiLocalization.of(context);
    final islanguageCodeEn =
        Localizations.localeOf(context).languageCode == "en";
    final homePageCubit = context.watch<HomePageCubit>();
    final homePageState = homePageCubit.state;
    return Scaffold(
      key: const ValueKey(keys.homePage),
      backgroundColor: const Color(0xffEAEAEA),
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, size: 30),
          tooltip: MaterialLocalizations.of(context).backButtonTooltip,
          onPressed: () async {
            await homePageCubit.resetPlan();
            await Navigator.maybePop(context);
          },
        ),
        title: Row(
          children: [
            Flexible(
                child: Text(
              homePageState.fromPlace.displayName(localization),
              style: const TextStyle(fontSize: 17),
              overflow: TextOverflow.clip,
            )),
            const Icon(
              Icons.arrow_right_alt,
              color: Colors.white,
              size: 35,
            ),
            Flexible(
                child: Text(
              homePageState.toPlace.displayName(localization),
              style: const TextStyle(fontSize: 17),
              overflow: TextOverflow.clip,
            )),
          ],
        ),
      ),
      body: Stack(
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Center(
                child: Image.asset(
                  'assets/images/background-image.png',
                  fit: BoxFit.cover,
                  height: MediaQuery.of(context).size.height / 3,
                ),
              ),
            ],
          ),
          if ((homePageState?.plan?.itineraries?.length ?? 0) == 0)
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 40),
              child: Center(
                child: Text(
                  islanguageCodeEn
                      ? "No result was found for the selected connection and time."
                      : "Für die angegebene Verbindung und Zeit wurde kein Ergebnis gefunden.",
                  style: theme.textTheme.bodyText1.copyWith(fontSize: 25),
                  textAlign: TextAlign.center,
                ),
              ),
            )
          else
            ListView.builder(
              shrinkWrap: true,
              padding: EdgeInsets.zero,
              itemCount: homePageState.plan.itineraries.length,
              itemBuilder: (_, index) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (index == 0)
                      Padding(
                        padding: const EdgeInsets.only(top: 40, bottom: 30),
                        child: Center(
                          child: Text(
                            islanguageCodeEn
                                ? "We found ${homePageState?.plan?.itineraries?.length} "
                                    "${homePageState.plan.itineraries.length > 1 ? "routes" : "route"} for you"
                                : "Es gibt ${homePageState?.plan?.itineraries?.length} mögliche Routen",
                            style: theme.textTheme.subtitle1
                                .copyWith(fontSize: 25),
                          ),
                        ),
                      ),
                    GestureDetector(
                      onTap: () {
                        _planPageController.inSelectedItinerary.add(
                          homePageState?.plan?.itineraries[index]
                              .copyWith(isOnlyShowItinerary: true),
                        );
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => BikeDetailScreen(
                              planPageController: _planPageController,
                            ),
                          ),
                        );
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 35),
                        margin: const EdgeInsets.symmetric(vertical: 10),
                        child: CardItinerary(
                          itinerary: homePageState?.plan?.itineraries[index],
                        ),
                      ),
                    ),
                    if (index == homePageState.plan.itineraries.length - 1)
                      Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(
                              top: 50,
                              bottom: 10,
                            ),
                            child: Center(
                              child: homePageState.isFetchLater
                                  ? const CircularProgressIndicator()
                                  : OutlinedButton(
                                      onPressed: () async {
                                        _fetchMoreitineraries(
                                            context: context,
                                            isFetchEarlier: false);
                                      },
                                      style: ButtonStyle(
                                        backgroundColor:
                                            MaterialStateProperty.all<Color>(
                                          const Color(0xffEAEAEA),
                                        ),
                                        padding: MaterialStateProperty.all<
                                                EdgeInsets>(
                                            const EdgeInsets.symmetric(
                                                horizontal: 10)),
                                        side: MaterialStateProperty.all<
                                            BorderSide>(
                                          BorderSide(
                                            color:
                                                theme.textTheme.subtitle1.color,
                                          ),
                                        ),
                                        shape: MaterialStateProperty.all<
                                            OutlinedBorder>(
                                          RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                          ),
                                        ),
                                        minimumSize:
                                            MaterialStateProperty.all<Size>(
                                          const Size(200, 50),
                                        ),
                                      ),
                                      child: Text(
                                        islanguageCodeEn
                                            ? "SHOW MORE"
                                            : "MEHR ANZEIGEN",
                                        style:
                                            theme.textTheme.subtitle1.copyWith(
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold,
                                        ),
                                        textAlign: TextAlign.center,
                                        maxLines: 1,
                                      ),
                                    ),
                            ),
                          ),
                          if (isPortrait)
                            SizedBox(
                              height: homePageState.plan.itineraries.length > 3
                                  ? 0
                                  : ((4 -
                                              homePageState
                                                  .plan.itineraries.length) *
                                          110.0) -
                                      80,
                            ),
                          SizedBox(
                            height: 200,
                          ),
                        ],
                      ),
                  ],
                );
              },
            ),
        ],
      ),
    );
  }

  Future<void> _fetchMoreitineraries({
    @required BuildContext context,
    @required bool isFetchEarlier,
  }) async {
    final TrufiLocalization localization = TrufiLocalization.of(context);
    final appReviewCubit = context.read<AppReviewCubit>();
    final homePageCubit = context.read<HomePageCubit>();
    final homePageState = homePageCubit.state;
    final payloadDataPlanCubit = context.read<PayloadDataPlanCubit>();
    final correlationId = context.read<PreferencesCubit>().state.correlationId;
    if (!homePageState.isFetchLater) {
      await homePageCubit
          .fetchMoreDeparturePlan(
            correlationId,
            localization,
            advancedOptions: payloadDataPlanCubit.state,
            isFetchEarlier: isFetchEarlier,
            itineraries: homePageState.plan.itineraries,
          )
          .then((value) => appReviewCubit.incrementReviewWorthyActions())
          .catchError((error) => onFetchError(context, error as Exception));
    }
    _planPageController =
        PlanPageController(homePageCubit.state.plan, widget.ad);
  }
}
