package app.trufi.hamburg_bike_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
