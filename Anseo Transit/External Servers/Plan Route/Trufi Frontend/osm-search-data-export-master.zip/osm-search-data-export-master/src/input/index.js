/* eslint-disable global-require */
module.exports = {
  jsonInput: require('./json'),
  memoryInput: require('./memory'),
  overpassInput: require('./overpass'),
  pbfInput: require('./pbf'),
};
