import 'package:mockito/mockito.dart';
import 'package:trufi_core/services/plan_request/request_manager.dart';

class MockRequestManager extends Mock implements RequestManager {}
