import 'package:mockito/mockito.dart';
import 'package:trufi_core/blocs/location_search_bloc.dart';

class MockLocationSearchBloc extends Mock implements LocationSearchBloc {}
