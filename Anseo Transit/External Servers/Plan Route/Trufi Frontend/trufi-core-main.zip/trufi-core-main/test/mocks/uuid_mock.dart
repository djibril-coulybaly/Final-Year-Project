import 'package:mockito/mockito.dart';
import 'package:uuid/uuid.dart';

class MockUuid extends Mock implements Uuid {}
