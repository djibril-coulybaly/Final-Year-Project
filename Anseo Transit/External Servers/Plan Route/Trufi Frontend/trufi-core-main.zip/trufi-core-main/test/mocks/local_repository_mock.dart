import 'package:mockito/mockito.dart';
import 'package:trufi_core/repository/local_repository.dart';

class MockLocalRepository extends Mock implements LocalRepository {}
