enum ServerType { defaultServer, graphQLServer }
