import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:trufi_core/blocs/configuration/configuration.dart';

class ConfigurationCubit extends Cubit<Configuration> {
  ConfigurationCubit(Configuration initialState) : super(initialState);
}
