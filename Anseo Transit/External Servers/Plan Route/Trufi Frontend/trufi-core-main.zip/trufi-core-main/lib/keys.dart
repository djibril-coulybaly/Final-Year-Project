const String homePage = '/';
const String homePageFromPlaceField = 'FromPlaceField';
const String homePageToPlaceField = 'ToPlaceField';
const String homePageSwapButton = 'SwapButton';

const String search = 'Search';
