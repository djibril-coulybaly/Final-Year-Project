## 2.0.0
🎉 Support for Flutter 2.0
🎉 A new way of Custom Translations
🎉 Usage of the gen-l10n way for translations

## 0.0.1

* TODO: Describe initial release.
