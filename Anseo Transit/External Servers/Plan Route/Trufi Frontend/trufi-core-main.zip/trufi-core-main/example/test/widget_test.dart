void main() {
/*
  TODO: Needs upgrade to newer version: https://github.com/flutter/flutter/issues/73061 - Problem with Null Saftey Upgrade

  testWidgets('Verify Platform version', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(TrufiApp());

    // Verify that platform version is retrieved.
    expect(
      find.byWidgetPredicate(
        (Widget widget) => widget is Text &&
                           widget.data.startsWith('Running on:'),
      ),
      findsOneWidget,
    );
  });*/
}
