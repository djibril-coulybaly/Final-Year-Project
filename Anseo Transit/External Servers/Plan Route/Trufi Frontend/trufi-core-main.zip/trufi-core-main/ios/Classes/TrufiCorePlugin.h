#import <Flutter/Flutter.h>

@interface TrufiCorePlugin : NSObject<FlutterPlugin>
@end
